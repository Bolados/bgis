create function st_area(text) returns double precision
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT public.ST_Area($1::public.geometry);
$$;

alter function st_area(text) owner to postgres;

