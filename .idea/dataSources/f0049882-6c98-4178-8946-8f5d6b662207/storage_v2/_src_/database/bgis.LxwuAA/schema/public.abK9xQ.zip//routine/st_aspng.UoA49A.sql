create function st_aspng(rast raster, nbands integer[], options text[] DEFAULT NULL::text[]) returns bytea
  immutable
  parallel safe
  language sql
as
$$
SELECT public.st_aspng(st_band($1, $2), $3)
$$;

comment on function st_aspng(raster, integer[], text[]) is 'args: rast, nbands, options=NULL - Return the raster tile selected bands as a single portable network graphics (PNG) image (byte array). If 1, 3, or 4 bands in raster and no bands are specified, then all bands are used. If more 2 or more than 4 bands and no bands specified, then only band 1 is used. Bands are mapped to RGB or RGBA space.';

alter function st_aspng(raster, integer[], text[]) owner to postgres;

