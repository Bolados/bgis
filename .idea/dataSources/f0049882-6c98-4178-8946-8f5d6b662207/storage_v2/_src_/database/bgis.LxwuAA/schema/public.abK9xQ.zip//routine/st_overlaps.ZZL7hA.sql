create function st_overlaps(geom1 geometry, geom2 geometry) returns boolean
  immutable
  parallel safe
  language sql
as
$$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_Overlaps($1,$2)
$$;

comment on function st_overlaps(geometry, geometry) is 'args: A, B - Returns TRUE if the Geometries share space, are of the same dimension, but are not completely contained by each other.';

alter function st_overlaps(geometry, geometry) owner to postgres;

